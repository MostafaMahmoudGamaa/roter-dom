import AllDaysLest from "./AllDaysLest";
import AddTraderF from "../../FAB/FAB";

export default function MainPageContainer({
  selectedDay,
  stockLoading,
  stockData,
  traders,
  children
}) {
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-6 dark:bg-gray-900">
      <div className="max-w-6xl h-full mx-auto text-center">
        <div className="flex items-center justify-between">
          <h1 className="dark:text-gray-100">اليوم : {selectedDay}</h1>
          <div>
            <AllDaysLest />
          </div>
        </div>

        {children}

        {/* الزرار العائم */}
        <div>
          <AddTraderF /> 
        </div>
      </div>
    </div>
  );
}