

export default function NotFoundPage() {
  return (
    <div className="flex fle">
      <h1>خطاء 404</h1>
      <h3>لم يتم العثور على الصفحه المطلوبه</h3>
    </div>
  );
}
